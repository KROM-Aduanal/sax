﻿Imports System.IO
Imports gsol.krom
Imports MongoDB.Bson
Imports MongoDB.Driver
Imports Syn.Documento
Imports Syn.Documento.Componentes
Imports Syn.Nucleo.RecursosComercioExterior.SeccionesFacturaComercial
Imports Syn.Nucleo.RecursosComercioExterior.CamposFacturaComercial
Imports Wma.Exceptions
Imports Syn.CustomBrokers.Controllers.IControladorFacturaComercial.Disponibilidades
Imports Syn.CustomBrokers.Controllers.IControladorFacturaComercial.Modalidades
Imports Rec.Globals.Controllers
Imports Syn.Utils

<DebuggerDisplay("{GetDebuggerDisplay(),nq}")>
Public Class ControladorFacturaComercial
    Implements IControladorFacturaComercial, ICloneable, IDisposable


#Region "Atributos"

    Private disposedValue As Boolean

    Private _seccionesCampos As List(Of SeccionesCamposGenerales)

    Private _listaObjetos As List(Of ObjectId)

    Private _listaFolios As List(Of String)

    Private _listadoCampos As Dictionary(Of ObjectId, Object)

    Private _listadoValoresObject As Dictionary(Of ObjectId, List(Of Nodo))

    Private _listadoValoresString As Dictionary(Of String, List(Of Nodo))

    Private _listado As Dictionary(Of Object, Object)

    Private _totalValorIncrementables As Double = 0

    Private _totalValorFletes As Double = 0

    Private _totalValorSeguros As Double = 0

    Private _totalValorEmbalajes As Double = 0

    Private _totalValorOtrosIncrementables As Double = 0

    Private _totalValorDescuentos As Double = 0

    Private _iControladorMonedas As IControladorMonedas

    Private _numeroAcuseValor As String

    Private _fechaAcuseValor As Date

#End Region

#Region "Propiedades"
    Public Property FacturasComerciales As List(Of ConstructorFacturaComercial) _
    Implements IControladorFacturaComercial.FacturasComerciales

    Public ReadOnly Property Documento As DocumentoElectronico _
    Implements IControladorFacturaComercial.Documento

    Public ReadOnly Property Documentos As List(Of DocumentoElectronico) _
    Implements IControladorFacturaComercial.Documentos

    Public Property Estado As TagWatcher _
    Implements IControladorFacturaComercial.Estado

    Public Property ModalidadTrabajo As IControladorFacturaComercial.Modalidades _
        Implements IControladorFacturaComercial.ModalidadTrabajo

    Public Property ConservarFacturas As Boolean _
        Implements IControladorFacturaComercial.ConservarFacturas

    Public Property Entorno As Integer _
    Implements IControladorFacturaComercial.Entorno

    Public Property DisponibilidadRecurso As IControladorFacturaComercial.Disponibilidades _
        Implements IControladorFacturaComercial.DisponibilidadRecurso

    Public ReadOnly Property FactorConfiabilidadIA As Double _
        Implements IControladorFacturaComercial.FactorConfiabilidadIA

#End Region

#Region "Constructores"
    Sub New(ByVal entorno_ As Integer,
        ByVal conservarFacturas_ As Boolean)

        _FacturasComerciales = New List(Of ConstructorFacturaComercial)

        Inicializa(Nothing,
               Externo,
               conservarFacturas_,
               entorno_,
               SinDefinir)

    End Sub

    Sub New(ByVal facturasComerciales_ As ConstructorFacturaComercial,
        ByVal entorno_ As Integer)

        _FacturasComerciales = New List(Of ConstructorFacturaComercial) From {facturasComerciales_}

        Inicializa(Nothing,
               Interno,
               True,
               entorno_,
               SinDefinir)

    End Sub

    Sub New(ByVal facturasComerciales_ As List(Of ConstructorFacturaComercial),
        ByVal entorno_ As Integer)

        _FacturasComerciales = facturasComerciales_

        Inicializa(Nothing,
               Interno,
               True,
               entorno_,
               SinDefinir)

    End Sub

    Public Sub New(ByVal idFactura_ As Object,
                   ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
                   ByVal entorno_ As Integer,
                   Optional conservarFacturas_ As Boolean = True
                   )

        Inicializa(idFactura_,
                   modalidadTrabajo_,
                   conservarFacturas_,
                   entorno_,
                   SinDefinir)

    End Sub

    Sub New(ByVal idFactura_ As ObjectId,
            ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
            ByVal entorno_ As Integer,
            Optional conservarFacturas_ As Boolean = True)



        Inicializa(idFactura_,
                   modalidadTrabajo_,
                   conservarFacturas_,
                   entorno_,
                   SinDefinir)

    End Sub
    Sub New(ByVal folioFactura_ As String,
            ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
            ByVal entorno_ As Integer,
            Optional conservarFacturas_ As Boolean = True)

        Inicializa(folioFactura_,
                   modalidadTrabajo_,
                   conservarFacturas_,
                   entorno_,
                   SinDefinir)

    End Sub

    Sub New(ByVal idsFacturas_ As List(Of ObjectId),
            ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
            ByVal entorno_ As Integer,
            Optional conservarFacturas_ As Boolean = True)

        Inicializa(idsFacturas_,
                   modalidadTrabajo_,
                   conservarFacturas_,
                   entorno_,
                   SinDefinir)

    End Sub


    Sub New(ByVal foliosFacturas_ As List(Of String),
            ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
            ByVal entorno_ As Integer,
            Optional conservarFacturas_ As Boolean = True)

        Inicializa(foliosFacturas_,
                   modalidadTrabajo_,
                   conservarFacturas_,
                   entorno_,
                   SinDefinir)


    End Sub

    Public Sub Inicializa(ByVal factura_ As Object,
                          ByVal modalidadTrabajo_ As IControladorFacturaComercial.Modalidades,
                          ByVal conservarFacturas_ As Boolean,
                          ByVal entorno_ As Integer?,
                          ByVal disponibilidadRecurso_ As IControladorFacturaComercial.Disponibilidades)

        _Estado = New TagWatcher

        _ModalidadTrabajo = modalidadTrabajo_

        _ConservarFacturas = conservarFacturas_

        _Entorno = entorno_

        _DisponibilidadRecurso = disponibilidadRecurso_

        If factura_ IsNot Nothing Then

            _Estado = ListaFacturas(factura_)

            _FacturasComerciales = _Estado.ObjectReturned

        End If


        If _FacturasComerciales Is Nothing Then

            _FacturasComerciales = New List(Of ConstructorFacturaComercial)

        End If

    End Sub
#End Region

#Region "Métodos"


    Public Sub ReiniciarControlador() _
        Implements IControladorFacturaComercial.ReiniciarControlador

        _Estado.
            SetError(Me, "Función aún no implementada")

    End Sub

    Public Sub CargaFacturas(documentoDigital_ As MemoryStream) _
    Implements IControladorFacturaComercial.CargaFacturas

        _Estado.
            SetError(Me, "Función aún no implementada")

    End Sub

    Public Sub CargaFacturas(documentoDigital_ As List(Of MemoryStream)) _
    Implements IControladorFacturaComercial.CargaFacturas

        _Estado.
            SetError(Me, "Función aún no implementada")

    End Sub

    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not disposedValue Then
            If disposing Then
                ' TODO: eliminar el estado administrado (objetos administrados)
            End If

            ' TODO: liberar los recursos no administrados (objetos no administrados) y reemplazar el finalizador
            ' TODO: establecer los campos grandes como NULL
            disposedValue = True
        End If
    End Sub

    ' ' TODO: reemplazar el finalizador solo si "Dispose(disposing As Boolean)" tiene código para liberar los recursos no administrados
    ' Protected Overrides Sub Finalize()
    '     ' No cambie este código. Coloque el código de limpieza en el método "Dispose(disposing As Boolean)".
    '     Dispose(disposing:=False)
    '     MyBase.Finalize()
    ' End Sub

    Public Sub Dispose() Implements IDisposable.Dispose
        ' No cambie este código. Coloque el código de limpieza en el método "Dispose(disposing As Boolean)".
        Dispose(disposing:=True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

#Region "Funciones privadas"

    Private Function ConsultaExterior(foliosFacturas_ As Object,
                                  tipoConsulta_ As Boolean) As TagWatcher

        With _Estado

            If _FacturasComerciales IsNot Nothing Then

                _FacturasComerciales = IIf(_ConservarFacturas,
                                       _FacturasComerciales,
                                       New List(Of ConstructorFacturaComercial))
            Else

                _FacturasComerciales = New List(Of ConstructorFacturaComercial)

            End If

            Using iEnlace_ As IEnlaceDatos = New EnlaceDatos With
               {.EspacioTrabajo = System.Web.HttpContext.Current.Session("EspacioTrabajoExtranet")}

                Dim operationsDB_ = iEnlace_.
                                GetMongoCollection(Of OperacionGenerica)((New ConstructorFacturaComercial).
                                GetType.Name)

                If tipoConsulta_ Then

                    Dim folioFactura_ As List(Of ObjectId) = foliosFacturas_

                    operationsDB_.
                    Aggregate().
                    Match(Function(a) folioFactura_.Contains(a.Id)).
                    ToList().
                    ForEach(Sub(item)

                                item.
                                Borrador.
                                Folder.
                                ArchivoPrincipal.
                                Dupla.
                                Fuente.
                                Id = item.Id.ToString

                                _FacturasComerciales.
                                Add(New ConstructorFacturaComercial(True,
                                                                    item.
                                                                    Borrador.
                                                                    Folder.
                                                                    ArchivoPrincipal.
                                                                    Dupla.
                                                                    Fuente))
                            End Sub)
                Else

                    Dim folioFactura_ As List(Of String) = foliosFacturas_

                    operationsDB_.
                    Aggregate().
                    Match(Function(a) folioFactura_.Contains(a.
                                                             Borrador.
                                                             Folder.
                                                             ArchivoPrincipal.
                                                             Dupla.
                                                             Fuente.
                                                             FolioDocumento)).
                   ToList().
                   ForEach(Sub(item)

                               item.
                               Borrador.
                               Folder.
                               ArchivoPrincipal.
                               Dupla.
                               Fuente.
                               Id = item.Id.ToString

                               _FacturasComerciales.
                               Add(New ConstructorFacturaComercial(True,
                                                                    item.
                                                                    Borrador.
                                                                    Folder.
                                                                    ArchivoPrincipal.
                                                                    Dupla.
                                                                    Fuente))
                           End Sub)
                End If

                If _FacturasComerciales.Count > 0 Then

                    .SetOK()

                    .ObjectReturned = _FacturasComerciales

                Else

                    .SetOKBut(Me, "Facturas comerciales no encontradas")

                End If

            End Using

            Return _Estado

        End With

    End Function

    Private Function ObtenerFacturas(idFacturas_ As List(Of ObjectId)) _
                                 As TagWatcher

        With _Estado

            Select Case _ModalidadTrabajo

                Case IControladorFacturaComercial.Modalidades.Interno

                    If Not _FacturasComerciales Is Nothing Then

                        If _FacturasComerciales.Count > 0 Then

                            Dim facturas_ = IIf(_ConservarFacturas,
                                             _FacturasComerciales,
                                             New List(Of ConstructorFacturaComercial))


                            For Each item_ In _FacturasComerciales.
                                Where(Function(f) idFacturas_.Contains(New ObjectId(f.Id)))

                                facturas_.Add(item_)

                            Next

                            If facturas_.Count > 0 Then

                                .SetOK()

                                .ObjectReturned = facturas_

                            Else

                                .SetOKBut(Me, "No se encuentran facturas en la batería actual")

                            End If

                        Else

                            .SetOKBut(Me, "No se cargaron las facturas")

                        End If

                    End If

                Case IControladorFacturaComercial.Modalidades.Externo

                    _Estado = ConsultaExterior(idFacturas_, True) 'True es para object

            End Select

            Return _Estado

        End With

    End Function

    Private Function ObtenerFacturas(foliosFacturas_ As List(Of String)) _
                                 As TagWatcher

        With _Estado

            Select Case _ModalidadTrabajo

                Case IControladorFacturaComercial.Modalidades.Interno

                    If _FacturasComerciales IsNot Nothing Then

                        If _FacturasComerciales.Count > 0 Then

                            Dim facturas_ = IIf(_ConservarFacturas,
                                            _FacturasComerciales,
                                            New List(Of ConstructorFacturaComercial))

                            For Each item_ In _FacturasComerciales.
                            Where(Function(f) foliosFacturas_.Contains(f.Seccion(SFAC1).
                                                                        Attribute(CA_NUMERO_FACTURA).
                                                                        Valor))

                                facturas_.Add(item_)

                            Next

                            If facturas_.Count > 0 Then

                                .SetOK()

                                .ObjectReturned = facturas_

                            Else

                                .SetOKBut(Me, "Ocurrió un problema al cargar las facturas en batería")

                            End If

                        Else

                            .SetOKBut(Me, "No hay facturas disponibles")

                        End If

                    Else

                        .SetOKBut(Me, "No se encuentran facturas en la batería actual")

                    End If

                Case IControladorFacturaComercial.Modalidades.Externo

                    _Estado = ConsultaExterior(foliosFacturas_, False)

            End Select

            Return _Estado

        End With

    End Function

    Private Function CalcularValorIncrementable(ByRef incrementable_ As Double,
                                            ByRef monedaIncrementable_ As String,
                                            ByRef fechaMoneda_ As Date) As Double
        With _Estado

            .SetOKInfo(Me, "Valor incrementable sin calcular")

            Try
                _iControladorMonedas = New ControladorMonedas

                _iControladorMonedas.
                ObtenerFactorTipodeCambio(monedaIncrementable_,
                                          Nothing,
                                          Nothing,
                                          fechaMoneda_)

                incrementable_ *= (_iControladorMonedas.TiposdeCambio(0).tipocambio *
                                     _iControladorMonedas.FactoresCambioRecientes(0).factor)

                If incrementable_ > 0.0 Then

                    .SetOK()

                    incrementable_ = incrementable_

                End If

            Catch ex As Exception

                .SetError(Me, ex.Message)

                incrementable_ = 0.00

            End Try

        End With

        Return incrementable_

    End Function

    Private Function ObtenerValorIncrementable(ByRef valorSeccion_ As Double,
                                           ByRef monedaSeccion_ As String,
                                           ByRef fechaMoneda_ As Date) As Double

        With _Estado

            If valorSeccion_ > 0 And
           monedaSeccion_ IsNot Nothing Then

                Return CalcularValorIncrementable(valorSeccion_,
                                              monedaSeccion_,
                                              fechaMoneda_)
            Else

                .SetOKBut(Me, "Parámetros sin valor")

                Return 0.00

            End If


        End With

    End Function

    Private Function SeccionesCampos(ByVal facturaComercial_ As TagWatcher,
                                 ByVal seccion_ As Integer,
                                 Optional listaCampos_ As List(Of Integer) = Nothing) As Object

        With _Estado

            If facturaComercial_ IsNot Nothing Then

                If facturaComercial_.ObjectReturned.Count > 0 Then

                    For Each factura_ In facturaComercial_.ObjectReturned

                        If listaCampos_ Is Nothing Then

                            If seccion_ <> 4 Then

                                With factura_.Seccion(seccion_)

                                    For i_ As Integer = 0 To .Nodos.Count - 1

                                        _listado.Add(.Nodos(i_).Nodos(0).Nombre,
                                         IIf(.Nodos(i_).Nodos(0).ValorPresentacion IsNot Nothing,
                                             .Nodos(i_).Nodos(0).ValorPresentacion,
                                             .Nodos(i_).Nodos(0).Valor))

                                    Next

                                    _listadoCampos.Add(ObjectId.Parse(factura_.Id), _listado)

                                End With

                            Else
                                With factura_

                                    For x_ As Integer = 30 To .Seccion(seccion_).Nodos.Count - 1

                                        Dim aux_ As New Dictionary(Of String, Object)

                                        For Each i_ In .Seccion(seccion_).Nodos(x_).Nodos

                                            aux_.Add(i_.Nodos(0).Nombre,
                                         IIf(i_.Nodos(0).ValorPresentacion IsNot Nothing,
                                             i_.Nodos(0).ValorPresentacion,
                                             i_.Nodos(0).Valor))
                                        Next

                                        _listado.Add(x_ - 29, aux_)

                                    Next

                                    _listadoCampos.Add(ObjectId.Parse(factura_.Id), _listado)

                                End With

                            End If

                        Else

                            With factura_.Seccion(seccion_)

                                For Each item_ In listaCampos_

                                    _listado.Add(.Attribute(item_).Nombre,
                                         IIf(.Attribute(item_).ValorPresentacion IsNot Nothing,
                                             .Attribute(item_).ValorPresentacion,
                                             .Attribute(item_).Valor))

                                Next

                                _listadoCampos.Add(ObjectId.Parse(factura_.Id), _listado)

                            End With

                        End If

                    Next

                Else

                    .SetOKBut(Me, "No hay facturas disponibles")

                End If

            Else

                .SetOKBut(Me, "No existen facturas cargadas en batería")

            End If

            If _listadoCampos.Count > 0 Then

                .SetOK()

                _listadoCampos = _listadoCampos

            Else

                .SetError(Me, "Ha ocurrido en el llenado del listado")

            End If


            Return _listadoCampos

        End With

    End Function

    Private Function ObtenerListaIconterms(ByRef _facturasComerciales As TagWatcher) _
                                       As TagWatcher

        With _Estado

            If _facturasComerciales IsNot Nothing Then

                _listado = SeccionesCampos(_facturasComerciales,
                                       SFAC1,
                                       New List(Of Integer) From {CA_CVE_INCOTERM})

                If _listado.Count > 0 Then

                    .SetOK()

                    .ObjectReturned = _listado

                Else

                    .SetOKBut(Me, "INCOTERMS no encontrados")

                End If

            Else

                .SetOKBut(Me, "No hay facturas disponibles")

            End If


            Return _Estado

        End With

    End Function

    Private Function ObtenerListaIncrementables(ByVal _facturasComerciales As TagWatcher) _
                                                As TagWatcher

        With _Estado

            If _facturasComerciales IsNot Nothing Then

                _listado = SeccionesCampos(_facturasComerciales, SFAC5)

                If _listado.Count > 0 Then

                    .SetOK()

                    .ObjectReturned = _listado

                Else

                    .SetError(Me, "No se puedo generar el listado")

                End If

            Else

                .SetOKBut(Me, "No hay facturas disponibles")

            End If

            Return _Estado

        End With

    End Function

    Private Function ObtenerTotalIncrementables(ByRef facturasDisponibles_ As TagWatcher,
                                                ByRef fechaMoneda_ As Date) _
                                                As TagWatcher

        With _Estado

            If facturasDisponibles_.ObjectReturned > 0 Then

                For Each facturaComercial_ In facturasDisponibles_.ObjectReturned

                    With facturaComercial_.Seccion(SFAC5)

                        _totalValorSeguros += ObtenerValorIncrementable(.Attribute(CA_SEGURO).Valor,
                                                               .Attribute(CA_MONEDA_SEGUROS).ValorPresentacion,
                                                               fechaMoneda_)

                        _totalValorFletes += ObtenerValorIncrementable(.Attribute(CA_FLETES).Valor,
                                                              .Attribute(CA_MONEDA_FLETES).ValorPresentacion,
                                                              fechaMoneda_)

                        _totalValorEmbalajes += ObtenerValorIncrementable(.Attribute(CA_EMBALAJES).Valor,
                                                                  .Attribute(CA_MONEDA_EMBALAJES).ValorPresentacion,
                                                                  fechaMoneda_)

                        _totalValorOtrosIncrementables += ObtenerValorIncrementable(.Attribute(CA_OTROS_INCREMENTABLES).Valor,
                                                                           .Attribute(CA_MONEDA_OTROS_INCREMENTABLES).ValorPresentacion,
                                                                           fechaMoneda_)

                        _totalValorDescuentos += ObtenerValorIncrementable(.Attribute(CA_DESCUENTOS).Valor,
                                                                  .Attribute(CA_MONEDA_DESCUENTOS).ValorPresentacion,
                                                                  fechaMoneda_)
                    End With

                Next

                _totalValorIncrementables = _totalValorFletes +
                                            _totalValorSeguros +
                                            _totalValorEmbalajes +
                                            _totalValorOtrosIncrementables +
                                            _totalValorDescuentos

                .SetOK()

                .ObjectReturned = _totalValorIncrementables

            Else

                .SetOKBut(Me, "No hay facturas disponibles")

            End If

            Return _Estado

        End With

    End Function

    Private Function ObtenerPartidas(ByVal _facturasComerciales As TagWatcher) _
                                 As TagWatcher

        With _Estado

            If _facturasComerciales.ObjectReturned > 0 Then

                _listadoCampos = SeccionesCampos(_facturasComerciales, SFAC4)

                If _listadoCampos.Count > 0 Then

                    .SetOK()

                    .ObjectReturned = _listadoCampos

                Else

                    .SetError(Me, "No se puedo generar el listado de partidas")

                End If

            Else

                .SetOKBut(Me, "No hay facturas disponibles")

            End If

            Return _Estado

        End With

    End Function

    Private Function ObtenerListaValores(idsFacturas_ As List(Of ObjectId),
                                     seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) _
                                    As TagWatcher

        With _Estado

            Try

                _listadoValoresObject = (New Organismo).ObtenerCamposSeccionExterior(idsFacturas_, New ConstructorFacturaComercial, seccionesCampos_)

                If _listadoValoresObject IsNot Nothing Then

                    If _listadoValoresObject.Count > 0 Then

                        .SetOK()

                        .ObjectReturned = _listadoValoresObject

                    Else

                        .SetError(Me, "Ocurrio un error al obtener la lista de valores")

                    End If

                Else

                    .SetOKBut(Me, "No se encontraron valores disponibles")

                End If

            Catch ex As Exception

                .SetError(Me, ex.Message)

            End Try

            Return _Estado

        End With

    End Function

    Private Function ObtenerListaValores(foliosFacturas_ As List(Of String),
                                     seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) _
                                     As TagWatcher

        With _Estado

            Try

                _listadoValoresString = (New Organismo).ObtenerCamposSeccionExterior(foliosFacturas_,
                                                                          New ConstructorFacturaComercial,
                                                                          seccionesCampos_)
                If _listadoValoresString IsNot Nothing Then

                    If _listadoValoresString.Count > 0 Then

                        .SetOK()

                        .ObjectReturned = _listadoValoresString

                    Else

                        .SetError(Me, "Ocurrió un error al obtener la lista de valores")

                    End If

                Else

                    .SetOKBut(Me, "No se encontraron valores disponibles")

                End If

            Catch ex As Exception

                .SetError(Me, ex.Message)

            End Try

            Return Estado

        End With

    End Function

#End Region

#Region "Funciones"

    'Interface
    Public Function ActualizarDatosAcuseValor(idFactura_ As ObjectId,
                                              valoresAcuseValor_ As List(Of String)) As TagWatcher _
                                              Implements IControladorFacturaComercial.ActualizarDatosAcuseValor

        With _Estado

            If Not idFactura_ = ObjectId.Empty And
               Not valoresAcuseValor_.Count = 0 Then

                If Not String.IsNullOrEmpty(valoresAcuseValor_(0)) And
                   Not String.IsNullOrEmpty(valoresAcuseValor_(1)) Then

                    If IsDate(valoresAcuseValor_(1)) Then

                        _numeroAcuseValor = valoresAcuseValor_(0)

                        _fechaAcuseValor = Convert.ToDateTime(valoresAcuseValor_(1)).Date.ToString("yyyy-MM-dd")

                        Using iEnlace_ As IEnlaceDatos = New EnlaceDatos With
                                                         {.EspacioTrabajo = System.Web.HttpContext.Current.Session("EspacioTrabajoExtranet")}


                            Dim operationsDB_ = iEnlace_.
                                                GetMongoCollection(Of OperacionGenerica)((New ConstructorFacturaComercial).
                                                GetType.Name)


                            Dim setStructureOfSubs_ = Builders(Of OperacionGenerica).Update.
                                                      Set(Of String)("Borrador.Folder.ArchivoPrincipal.Dupla.Fuente.Documento.Parts.Encabezado.0.Nodos.0.Nodos.1.Nodos.0.Valor", _numeroAcuseValor).
                                                      Set(Of String)("Borrador.Folder.ArchivoPrincipal.Dupla.Fuente.Documento.Parts.Encabezado.0.Nodos.0.Nodos.3.Nodos.0.Valor", _fechaAcuseValor)

                            Dim result_ = operationsDB_.UpdateOne(Function(x) x.Id = idFactura_, setStructureOfSubs_)

                            If result_.MatchedCount <> 0 Then

                                .SetOK()

                            ElseIf result_.UpsertedId IsNot Nothing Then

                                .SetOK()

                            Else

                                .SetError(Me, "No se generaron cambios")

                            End If

                        End Using

                    Else

                        .SetOKBut(Me, "Se esperaba una fecha válida")

                    End If

                Else

                    .SetOKBut(Me, "Se esperaban valores válidos")

                End If

            Else

                .SetOKBut(Me, "No se encontraron valores disponibles")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaFacturas(idFactura_ As ObjectId) As TagWatcher _
                                Implements IControladorFacturaComercial.ListaFacturas

        With _Estado

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _listaObjetos = New List(Of ObjectId) From {idFactura_}

                    _Estado = ObtenerFacturas(_listaObjetos)

                Else

                    .SetError(Me, "Facturas no disponibles")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaFacturas(idsFacturas_ As List(Of ObjectId)) As TagWatcher _
                                Implements IControladorFacturaComercial.ListaFacturas
        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count > 0 Then

                    _Estado = ObtenerFacturas(idsFacturas_)

                Else

                    .SetError(Me, "Facturas no disponibles")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaFacturas(folio_ As String) As TagWatcher _
                                Implements IControladorFacturaComercial.ListaFacturas

        With _Estado

            If _Entorno <> 0 Then

                If folio_ IsNot Nothing Then

                    _Estado = ObtenerFacturas(New List(Of String) From {folio_})

                Else

                    .SetError(Me, "Facturas no disponibles")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaFacturas(folios_ As List(Of String)) As TagWatcher _
                                Implements IControladorFacturaComercial.ListaFacturas

        With _Estado

            If _Entorno <> 0 Then

                If folios_ IsNot Nothing Then

                    _Estado = ObtenerFacturas(folios_)

                Else

                    .SetError(Me, "Facturas no disponibles")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function CargaFacturas(listaFacturas_ As List(Of ConstructorFacturaComercial)) As TagWatcher _
                                Implements IControladorFacturaComercial.CargaFacturas

        With _Estado

            .SetOKBut(Me, "Función aún no implementada")

            Return _Estado

        End With

    End Function

    Public Function FirmaDigital(Of T)(_id As ObjectId) As String _
                            Implements IControladorFacturaComercial.FirmaDigital

        With _Estado

            .SetOKBut(Me, "Función aún no implementada")

            Return "Sin firma"

        End With

    End Function

    Public Function FacturaDisponible(idFactura_ As ObjectId) As Boolean _
                                    Implements IControladorFacturaComercial.FacturaDisponible

        With _Estado

            .SetOKBut(Me, "Función aún no implementada")

            Return False

        End With

    End Function

    Public Function FacturaDisponible(folioFactura_ As String) As Boolean _
                                    Implements IControladorFacturaComercial.FacturaDisponible

        With _Estado

            .SetOKBut(Me, "Función aún no implementada")

            Return False

        End With

    End Function

    'Total incrementables
    Function TotalIncrementables() As TagWatcher _
                             Implements IControladorFacturaComercial.TotalIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If _FacturasComerciales IsNot Nothing Then

                    If _FacturasComerciales.Count > 0 Then

                        .ObjectReturned = _FacturasComerciales

                        _Estado = ObtenerTotalIncrementables(_Estado, Date.Now)

                    Else

                        .SetError(Me, "Total de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function TotalIncrementables(ByVal idFactura_ As ObjectId,
                             ByVal fechaMoneda_ As Date) As TagWatcher _
                             Implements IControladorFacturaComercial.TotalIncrementables

        With _Estado

            _Estado.SetError(Me, "Facturas no disponibles")

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _Estado = ListaFacturas(idFactura_)

                    If _Estado.ResultsCount <> 0 Then

                        _Estado = ObtenerTotalIncrementables(_Estado, fechaMoneda_)

                    Else

                        .SetError(Me, "Total de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "ObjectId no disponible")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function TotalIncrementables(ByVal idsFacturas_ As List(Of ObjectId),
                             ByVal fechaMoneda_ As Date) As TagWatcher _
                             Implements IControladorFacturaComercial.TotalIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count() > 0 Then

                    _Estado = ObtenerFacturas(idsFacturas_)

                    If _Estado.ResultsCount <> 0 Then

                        _Estado = ObtenerTotalIncrementables(_Estado, fechaMoneda_)

                    Else

                        .SetError(Me, "Total de incrementables por objectId sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Lista de ObjectId no disponibles")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function TotalIncrementables(ByVal folioFactura_ As String,
                             ByVal fechaMoneda_ As Date) As TagWatcher _
                             Implements IControladorFacturaComercial.TotalIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If folioFactura_ IsNot Nothing Then

                    _Estado = ListaFacturas(folioFactura_)

                    If .ResultsCount <> 0 Then

                        Return ObtenerTotalIncrementables(_Estado, fechaMoneda_)

                    Else

                        .SetError(Me, "Total de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Folio de factura no disponible")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function TotalIncrementables(ByVal foliosFacturas_ As List(Of String),
                             ByVal fechaMoneda_ As Date) As TagWatcher _
                             Implements IControladorFacturaComercial.TotalIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If foliosFacturas_ IsNot Nothing Then

                    _Estado = ListaFacturas(foliosFacturas_)

                    If .ResultsCount <> 0 Then

                        Return ObtenerTotalIncrementables(_Estado, fechaMoneda_)

                    Else

                        .SetError(Me, "Total de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Folio de factura no disponible")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    'Lista incrementables
    Function ListaIncrementables() As TagWatcher _
    Implements IControladorFacturaComercial.ListaIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If _FacturasComerciales IsNot Nothing Then

                    If _FacturasComerciales.Count > 0 Then

                        .ObjectReturned = _FacturasComerciales

                        _Estado = ObtenerListaIncrementables(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de incrementables")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncrementables(ByVal idFactura_ As ObjectId) As TagWatcher _
                             Implements IControladorFacturaComercial.ListaIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _Estado = ListaFacturas(idFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIncrementables(_Estado)

                    Else

                        .SetError(Me, "Lista de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncrementables(ByVal idsFacturas_ As List(Of ObjectId)) As TagWatcher _
                             Implements IControladorFacturaComercial.ListaIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count() > 0 Then

                    _Estado = ListaFacturas(idsFacturas_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIncrementables(_Estado)

                    Else

                        .SetError(Me, "Lista de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncrementables(ByVal folioFactura_ As String) As TagWatcher _
                             Implements IControladorFacturaComercial.ListaIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If folioFactura_ IsNot Nothing Then

                    _Estado = ListaFacturas(folioFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIncrementables(_Estado)

                    Else

                        .SetError(Me, "Lista de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncrementables(ByVal foliosFacturas_ As List(Of String)) As TagWatcher _
                             Implements IControladorFacturaComercial.ListaIncrementables

        With _Estado

            If _Entorno <> 0 Then

                If foliosFacturas_ IsNot Nothing Then

                    _Estado = ListaFacturas(foliosFacturas_)

                    If .ResultsCount <> 0 Then

                        Return ObtenerListaIncrementables(_Estado)

                    Else

                        .SetError(Me, "Lista de incrementables sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    'Lista Icoterms
    Function ListaIncoterms() As TagWatcher _
    Implements IControladorFacturaComercial.ListaIncoterms

        With _Estado

            If _Entorno <> 0 Then

                If _FacturasComerciales IsNot Nothing Then

                    If _FacturasComerciales.Count > 0 Then

                        .ObjectReturned = _FacturasComerciales

                        _Estado = ObtenerListaIconterms(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de incoterms")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncoterms(ByVal idFactura_ As ObjectId) As TagWatcher _
                        Implements IControladorFacturaComercial.ListaIncoterms

        With _Estado

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _Estado = ListaFacturas(idFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIconterms(_Estado)

                    Else

                        .SetError(Me, "Lista de incortems sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncoterms(ByVal idsFacturas_ As List(Of ObjectId)) As TagWatcher _
                        Implements IControladorFacturaComercial.ListaIncoterms

        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count() > 0 Then

                    _Estado = ObtenerFacturas(idsFacturas_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIconterms(_Estado)

                    Else

                        .SetError(Me, "Lista de incortems sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncoterms(ByVal folioFactura_ As String) As TagWatcher _
                        Implements IControladorFacturaComercial.ListaIncoterms

        With _Estado

            If _Entorno <> 0 Then

                If folioFactura_ IsNot Nothing Then

                    _Estado = ListaFacturas(folioFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIconterms(_Estado)

                    Else

                        .SetError(Me, "Lista de incortems sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaIncoterms(ByVal foliosFacturas_ As List(Of String)) As TagWatcher _
                        Implements IControladorFacturaComercial.ListaIncoterms

        With _Estado

            If _Entorno <> 0 Then

                If foliosFacturas_.Count() > 0 Then

                    _Estado = ListaFacturas(foliosFacturas_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerListaIconterms(_Estado)

                    Else

                        .SetError(Me, "Lista de incortems sin definir")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    'Partidas
    Function ListaPartidas() As TagWatcher _
    Implements IControladorFacturaComercial.ListaPartidas

        With _Estado

            If _Entorno <> 0 Then

                If _FacturasComerciales IsNot Nothing Then

                    If _FacturasComerciales.Count > 0 Then

                        .ObjectReturned = _FacturasComerciales

                        _Estado = ObtenerPartidas(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de partidas")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaPartidas(ByVal idFactura_ As ObjectId) As TagWatcher _
                       Implements IControladorFacturaComercial.ListaPartidas

        With _Estado

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _Estado = ListaFacturas(idFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerPartidas(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de partidas")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaPartidas(ByVal idsFacturas_ As List(Of ObjectId)) As TagWatcher _
                       Implements IControladorFacturaComercial.ListaPartidas

        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count() > 0 Then

                    _Estado = ListaFacturas(idsFacturas_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerPartidas(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de partidas")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaPartidas(ByVal folioFactura_ As String) As TagWatcher _
                       Implements IControladorFacturaComercial.ListaPartidas

        With _Estado

            If _Entorno <> 0 Then

                If folioFactura_ IsNot Nothing Then

                    _Estado = ListaFacturas(folioFactura_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerPartidas(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de partidas")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

        End With

        Return _Estado

    End Function

    Function ListaPartidas(ByVal foliosFacturas_ As List(Of String)) As TagWatcher _
                   Implements IControladorFacturaComercial.ListaPartidas

        With _Estado

            If _Entorno <> 0 Then

                If foliosFacturas_.Count() > 0 Then

                    _Estado = ListaFacturas(foliosFacturas_)

                    If .ResultsCount <> 0 Then

                        _Estado = ObtenerPartidas(_Estado)

                    Else

                        .SetError(Me, "Ha ocurrido un error al obtener la lista de partidas")

                    End If

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    'Navegacion
    Function ListaCampos(ByVal idFactura_ As ObjectId,
                     seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) As TagWatcher _
                     Implements IControladorFacturaComercial.ListaCampos

        With _Estado

            If _Entorno <> 0 Then

                If Not idFactura_ = ObjectId.Empty Then

                    _Estado = ObtenerListaValores(New List(Of ObjectId) From {idFactura_},
                                                                              seccionesCampos_)

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Function ListaCampos(ByVal idsFacturas_ As List(Of ObjectId),
                     ByVal seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) As TagWatcher _
                     Implements IControladorFacturaComercial.ListaCampos

        With _Estado

            If _Entorno <> 0 Then

                If idsFacturas_.Count() > 0 Then

                    Return ObtenerListaValores(idsFacturas_, seccionesCampos_)

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaCampos(ByVal folioFactura_ As String,
                     ByVal seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) As TagWatcher _
                     Implements IControladorFacturaComercial.ListaCampos

        With _Estado

            If _Entorno <> 0 Then

                If folioFactura_ IsNot Nothing Then

                    Return ObtenerListaValores(New List(Of String) From {folioFactura_},
                                                                         seccionesCampos_)

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ListaCampos(ByVal foliosFacturas_ As List(Of String),
                     ByVal seccionesCampos_ As Dictionary(Of [Enum], List(Of [Enum]))) As TagWatcher _
                     Implements IControladorFacturaComercial.ListaCampos

        With _Estado

            If _Entorno <> 0 Then

                If foliosFacturas_.Count() > 0 Then

                    Return ObtenerListaValores(foliosFacturas_, seccionesCampos_)

                Else

                    .SetOKBut(Me, "Facturas no disponibles en batería")

                End If

            Else

                .SetOKBut(Me, "Entorno no puede ser 0")

            End If

            Return _Estado

        End With

    End Function

    Public Function ConsultaPLNFactura(consulta_ As String) As BsonDocument _
    Implements IControladorFacturaComercial.ConsultaPLNFactura
        Throw New NotImplementedException()
    End Function

    Public Function Clone() As Object _
    Implements ICloneable.Clone
        Throw New NotImplementedException()
    End Function

    Private Function GetDebuggerDisplay() As String
        Return ToString()
    End Function

#End Region
End Class